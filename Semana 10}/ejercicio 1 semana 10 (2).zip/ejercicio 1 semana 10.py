print("semanana no. 10, ejercicio 1")
mes=int(input("ingrese un numero entr 1 y 12: "))
if mes<1 or mes>12: 
    print("error el numero debe de estar entre 1 y 12 ")
else: 
    if mes==1:
        print("mes: enero")
    elif mes==2:
        print("mes: febrero")
    elif mes==3:
        print("mes: marzo")
    elif mes==4:
        print("mes: abril")
    elif mes==5:
        print("mes: mayo")
    elif mes==6:
        print("mes: junio")
    elif mes==7:
        print("mes: julio")
    elif mes==8:
        print("mes: agosto")
    elif mes==9:
        print("mes: septiembre")
    elif mes==10:
        print("mes: octubre")
    elif mes==11:
        print("mes: nobiembre")
    elif mes==12:
        print("mes: diciembre")

#Ejercicio No.2 semana 10 
    A=input("ingrese el primer numero: ")
    B=input("ingrese el segundo numero: ")
    C=input("ingrese el tercer numero: ")

if A > B:
    if A > C:
        print("El mayor es:", A)
    else:
        print("El mayor es:", C)
elif A == B:
    if A > C:
        print("Los mayores son:", A, "y", B)
    elif A == C:
        print("Los tres valores son iguales")
    else:
        print("El mayor es:", C)
else:
    if B > C:
        print("El mayor es:", B)
    elif B == C:
        print("Los mayores son:", B, "y", C)
    else:
        print("El mayor es:", C)
    if A > C:
        print("Los mayores son:", A, "y", B)
    elif A == C:
        print("Los tres valores son iguales")
    else:
        print("El mayor es:", C)
    if B > C:
        print("El mayor es:", B)
    elif B== C:
        print("Los mayores son:", B, "y", C)
    else:
        print("El mayor es:", C)

#Ejercicio no. 3 
        
        mes=int(input("Ingrese su mes de nacimiento con números del 1 al 12: "))
if mes in range (1,13):
    día=int(input("Ingrese su fecha de nacimiento debe de ser entre 1 y 31 : "))
else:
    print("Error: el mes debe de estar entre 1 y 12")
if día in range (1,31):
    True
else:
    print("Ingrese una fecha válida, por favor")

if mes==1:
 if día in range(20,32):
    print("Tu signo zodiacal es: Acuario")
if mes==2:
  if día in range (1,19):
    print("Tu signo zodiacal es: Acuario")
    
if mes ==2:
   if día in range (19,29):
      print("Tu signo zodiacal es: Piscis")
if mes ==3:
   if día in range (1,21):
      print("Tu signo zodiacal es: Piscis")

if mes == 3:
   if día in range (21,32):
      print("Tu signo zodiacal es: Aries")
if mes==4:
   if día in range (1,20):
      print("Tu signo zodiacal es: Aries")

if mes==4:
   if día in range(20,31):
      print("Tu signo zodiacal es: Tauro")
if mes==5:
   if día in range (1,21):
      print("Tu signo zodiacal es: Tauro")

if mes==5:
   if día in range(21,32):
      print("Tu signo zodiacal es: Géminis")
if mes==6:
   if día in range (1,21):
      print("Tu signo zodiacal es: Géminis")

if mes==6:
   if día in range(21,31):
      print("Tu signo zodiacal es: Cancer")
if mes==7:
   if día in range(1,23):
      print("Tu signo zodiacal es: Cancer")

if mes==7:
   if día in range(23,32):
      print("Tu signo zodiacal es: Leo")
if mes==8:
   if día in range (1,23):
      print("Tu signo zodiacal es: Leo")

if mes==8:
   if día in range(23,32):
      print("Tu signo zodiacal es: Virgo")
if mes==9:
   if día in range(1,23):
      print("Tu signo zodiacal es: Virgo")

if mes==9:
   if día in range(23,31):
      print("Tu signo zodiacal es: Libra")
if mes==10:
   if día in range(1,23):
      print("Tu signo zodiacal es: Libra")

if mes==10:
   if día in range (23,32):
      print("Tu signo zodiacal es: Escorpio")
if mes==11:
   if día in range(1,22):
      print("Tu signo zodiacal es: Escorpio")

if mes==11:
   if día in range(22,31):
      print("Tu signo zodiacal es: Sagitario")
if mes==12:
   if día in range(1,22):
      print("Tu signo zodiacal es: Sagitario")

if mes==12:
   if día	in range(22,32):
      print("Tu signo zodiacal es: Capricornio")
if mes==1:
   if día in range(1,20):
       print("Tu signo zodiacal es: Capricornio")
      
if mes==1:
 if día in range(20,32):
    print("Tu signo zodiacal es: Acuario")
if mes==2:
  if día in range (1,19):
    print("Tu signo zodiacal es: Acuario")

if mes ==2:
   if día in range (19,29):
      print("Tu signo zodiacal es: Piscis")
if mes ==3:
   if día in range (1,21):
      print("Tu signo zodiacal es: Piscis")